configuration ConfigNetworkDNSandDomain
{
    param
    (
        [string[]]$NodeName       = 'localhost',
        [string[]]$Domain         = 'mydomain.local',
        [string]$DnsServerAddress = '10.2.1.88',
        $virtualMachineAdminPassword,
	    $virtualMachineAdminUserName,
        [string[]]$JoinOU,         
        [ValidateSet("IPv4","IPv6")]
        [string]$AddressFamily = 'IPv4'
    )

    Import-DscResource -Module xNetworking
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'xDSCDomainjoin'

    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    $uname       = $virtualMachineAdminUserName
    $pass        = $virtualMachineAdminPassword | convertto-securestring
    $Credential  = new-object -typename System.Management.Automation.PSCredential -argumentlist $uname,$pass

    Node $NodeName
    {
        xDnsServerAddress DnsServerAddress
        {
            Address        = $DnsServerAddress
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = $AddressFamily
        }

        xDSCDomainjoin JoinDomain
    	{
	    Domain = $Domain 
	    Credential = $Credential  # Credential to join to domain
            JoinOU = "OU=TestOU,DC=mydomain,DC=local"
    	}
    }
}