configuration ConfigNetworkDNSandDomain
{
    param
    (
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [System.String] $Domain          = 'mydomain.local',
        [string] $JoinOU                 = "OU=TestOU,DC=mydomain,DC=local"
    )

    Import-DscResource -Module xNetworking
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource -ModuleName 'xDSCDomainjoin'

    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    #$uname       = $UserName
    #$pass        = $Password
    #$secureStringPwd = $pass | ConvertTo-SecureString -AsPlainText -Force
    #[PSCredential] $Credential = New-Object System.Management.Automation.PSCredential -ArgumentList ($uname, $secureStringPwd)
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${Domain}\$($Admincreds.UserName)", $Admincreds.Password)
    
    Node $NodeName
    {
        xDSCDomainjoin JoinDomain
    	{
            Domain      = $Domain 
            Credential  = $DomainCreds  # Credential to join to domain
            JoinOU      = $JoinOU
        }
    }
}